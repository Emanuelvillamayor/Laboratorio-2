﻿public enum ELibro
{
Manual,
Novela,
Ambos
}